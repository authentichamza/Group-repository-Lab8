#include<iostream>
#include<string>
using namespace std;
class ZooAnimal
{
private:
  string *Name;
  int cageNumber=0;
  int weightDate=0;
  int weight=0;
public:
//ZooAnimal(string *nme,int cN,string wD,int w){
  //Name[]=new char[15];
  //for(int i=0;i<Name.length();i++)
  //Name[i]=nme[i];
  //cageNumber=cN;
  //weightDate=wD;
  //weight=w;
 //}
  int operator--(int a){
    weight--;
  }
  int getWeight(){
    return weight;
  }
 void setWeight(int n){
    weight=n;
  }
};
int main() {
  ZooAnimal Zoo1;
  Zoo1.setWeight(9);
  cout<<"Weight before loss "<<Zoo1.getWeight()<<endl;
  Zoo1--;
  cout<<"Weight after loss "<<Zoo1.getWeight()<<endl;
  return 0;
}
