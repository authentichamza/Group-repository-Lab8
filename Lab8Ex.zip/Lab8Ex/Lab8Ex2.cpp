#include<iostream>
using namespace std;
#include<string>
class Date{
private:
  int year,month,day;
  string MONTHS[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
  string DAY[]={"Sunday","Monday","Tuesday","Wednessday","Thursday","Friday","Saturday"};
  int DAYSinMONTH[12]={31,28,31,30,31,30,31,31,30,31,30,31};
public:
  Date(int y,int m,int d){
    year=y;
    month=m;
    day=d;
  }
  void setDate(int y,int m,int d){
    year=y;
    month=m;
    day=d;
  }
  bool isValidDate(int y,int m,int d){
    if((m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || m==12)&&(d>31)){
      return false;}

    else if(m==2 && d>28){
        return false;
      }
    else if((m==4 || m==6 || m==9 ||  m==11)&&(d>30)){
        return false;
      }
    else {
      return true;
    }
  }
  void getDayOfWeek(){
    for(int i=0;i<)

  }
  int getYear(){
    return year;
  }
  int getMonth(){
    return month;
  }
  int getDay(){
    return day;
  }
  void print(){
    cout<<year<<"/"<<month<<"/"<<day<<endl;
  }
};

int main(){
  Date d1(2017,8,23);
  d1.setDate(2017,8,23);
  d1.isValidDate(2017,8,23);
  d1.print();
  return 0;
}
